package game;

import interfaces.IModel;
import util.GameSettings;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * This class represents the state of the game.
 * It has been partially implemented, but needs to be completed by you.
 *
 * @author <YOUR UUN>
 */
public class Model implements IModel
{
	// A reference to the game settings from which you can retrieve the number
	// of rows and columns the board has and how long the win streak is.
	private GameSettings settings;
	int[][] board;
	int sum = 0;
	int concede;
	int score_1 =0;
	int score_2 =0;
	int count=0;
	int score ;
	int count_opp;
	int bonus;
	int bonus_opp;
	int count_empty;

	// The default constructor.
	public Model()
	{
		// You probably won't need this.
	}
	
	// A constructor that takes another instance of the same type as its parameter.
	// This is called a copy constructor.
	public Model(IModel model)
	{
		// You may (or may not) find this useful for advanced tasks.
		this.settings = model.getGameSettings() ;
		this.sum = (model.getActivePlayer()+1)%2;
		board = new int[model.getGameSettings().nrRows][model.getGameSettings().nrCols];
		for (int i =0; i < model.getGameSettings().nrRows;i++){
			for(int j = 0; j < model.getGameSettings().nrCols; j++){
				board[i][j] = model.getPieceIn(i,j);
			}
		}



	}

	public void changeSum(int i){
		sum = i;
	}


	// Called when a new game is started on an empty board.
	public void initNewGame(GameSettings settings)
	{
		this.settings = settings;
		board = new int[getGameSettings().nrRows][getGameSettings().nrCols];
		for (int i =0; i < getGameSettings().nrRows;i++){
			for(int j = 0; j < settings.nrCols; j++){
				board[i][j] = 0;
			}
		}
		concede = 0;
		sum = 0;
		// This method still needs to be extended.
	}


	// Called when a game state should be loaded from the given file.
	public void initSavedGame(String fileName)
	{
		// This is an advanced feature. If not attempting it, you can ignore this method.
		try {
			File last_file = new File("saves" + "/" +fileName);
			Scanner myReader = new Scanner(last_file);
			String data = new String();
			while (myReader.hasNextLine()) {
				data =  data + " " + myReader.nextLine() ;
			}
			String[] Data = data.split(" ");

			int nrRows = Integer.parseInt(Data[1]);
			int nrCols = Integer.parseInt(Data[2]);
			int streak = Integer.parseInt(Data[3]);
			settings = new GameSettings(nrRows, nrCols, streak);

			String all = new String();
			int c = 0;
			while(c<nrRows){
				all = all +Data[c+5];
				c++;
			}
			String[] split_Data = all.split("");

			board = new int[nrRows][nrCols];
			for (int i =0; i < nrRows;i++){
				for(int j = 0; j < nrCols; j++){
					board[i][j] = Integer.parseInt(split_Data[nrCols*i+j]);
					if(board[i][j] !=0){
						sum = sum+1;
					}
				}
			}


			concede = 0;

			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
	
	// Returns whether or not the passed in move is valid at this time.
	public boolean isMoveValid(int move) {
		// Assuming all moves are valid.
		if (move < -1) {
			return false;
		}
		if (move > getGameSettings().nrRows ) {
			return false;
		}if (move == -1 ){
			return true;
	    }  if (board [0][move] != 0){
			return false;
	    }else{
		    return true;
	    }
	}
	
	// Actions the given move if it is valid. Otherwise, does nothing.
	public void makeMove(int move) {
		// Not doing anything here yet.
		int l = getGameSettings().nrRows - 1;
		if (move != -1) {
			while (board[l][move] != 0) {
				l--;
			}
			board[l][move] = getActivePlayer();
			sum = sum +1;
		} else {
			concede = -1;
		}
	}

	// Returns one of the following codes to indicate the game's current status.
	// IModel.java in the "interfaces" package defines constants you can use for this.
	// 0 = Game in progress
	// 1 = Player 1 has won
	// 2 = Player 2 has won
	// 3 = Tie (board is full and there is no winner)
	public byte getGameStatus() {
		// Assuming the game is never ending.
		int all = 0;
		int status = 0;
		for (int i = 0; i < getGameSettings().nrRows; i++) {
			for (int j = 0; j < settings.nrCols; j++) {
				if (board[i][j] != 0) {
					all = all + 1;
				}
			}
		}

		int k ;


		if ((sum%2 == 0) && (concede == -1)){
			status = 2;
		} if ((sum%2 == 1) && (concede == -1)) {
			status = 1;
		}if (all == getGameSettings().nrRows* settings.nrCols){
			status = 3;
		}
        //cross 4
		for (int row = 0; row < settings.nrRows; row++){
			for (int col = 0; col < settings.nrCols- getGameSettings().minStreakLength + 1; col++){
				if(board [row][col] != 0){
					k = 0;
					for (int col_plus = 0;col_plus < getGameSettings().minStreakLength; col_plus++){
						if (board [row][col] == board[row][col+col_plus] ){
							k = k+1;
						}
					}
					if ( k == settings.minStreakLength){
						status = board [row][col];
					}
				}
			}
		}
        // up and down
		for (int row = 0; row < settings.nrRows- getGameSettings().minStreakLength + 1; row++){
			for (int col = 0; col < settings.nrCols; col++){
				if(board [row][col] != 0){
					k = 0;
					for (int row_plus = 0;row_plus < getGameSettings().minStreakLength; row_plus++){
						if (board [row][col] == board[row+row_plus][col] ){
							k = k+1;
						}
					}
					if ( k == settings.minStreakLength){
						status = board [row][col];
					}
				}
			}
		}

        // RightDiagonal
		for (int row = 0; row < settings.nrRows - getGameSettings().minStreakLength + 1; row++){
			for (int col = getGameSettings().minStreakLength-1;  col< settings.nrCols; col++){
				if(board [row][col] != 0){
					k = 0;
					for (int plus = 0;plus < getGameSettings().minStreakLength; plus++){
						if (board [row][col] == board[row+plus][col-plus] ){
							k = k+1;
						}
					}
					if ( k == settings.minStreakLength){
						status = board [row][col];
					}
				}
			}
		}

        //LeftDiagonal
		for (int row = 0;row < settings.nrRows - getGameSettings().minStreakLength + 1; row++){
			for (int col = 0; col < settings.nrCols - getGameSettings().minStreakLength + 1; col++){
				if(board [row][col] != 0){
					k = 0;
					for (int plus = 0;plus < getGameSettings().minStreakLength; plus++){
						if (board [row][col] == board[row+plus][col+plus] ){
							k = k+1;
						}
					}
					if ( k == settings.minStreakLength){
						status = board [row][col];
					}
				}
			}
		}
		if (status == 3){
			return IModel.GAME_STATUS_TIE;
		}if (status == 2){
			return IModel.GAME_STATUS_WIN_2;
		} if (status == 1 ) {
			return IModel.GAME_STATUS_WIN_1;
		}else{
			return IModel.GAME_STATUS_ONGOING;
		}

	}

	// Returns the number of the player whose turn it is.
	public byte getActivePlayer()
	{
		// Assuming it is always the turn of player 1.
		if (sum%2 == 0) {
			return 1;
		} else {
			return 2;
		}
	}

	// Returns the owner of the piece in the given row and column on the board.
	// Return 1 or 2 for players 1 and 2 respectively or 0 for empty cells.
	public byte getPieceIn(int row, int column)
	{
		if (board [row][column] == 1){
			return 1;
		} if (board [row][column] == 2){
			return 2;
	    } else {
			return 0;
	    }
	}

	// Returns a reference to the game settings, from which you can retrieve the
	// number of rows and columns the board has and how long the win streak is.
	public GameSettings getGameSettings()
	{
		return settings;
	}
	
	// =========================================================================
	// ================================ HELPERS ================================
	// =========================================================================
	
	// You may find it useful to define some helper methods here.
    public int score_count(int player) {
		//score for cross
		for (int row = 0; row < settings.nrRows; row++) {
			for (int col = 0; col < settings.nrCols - getGameSettings().minStreakLength + 1; col++) {
				count = 0;
				count_opp = 0;
				bonus_opp =0;
				bonus =0;
				for (int col_plus = 0; col_plus < getGameSettings().minStreakLength; col_plus++) {
					if (board[row][col] == board[row][col + col_plus] && board[row][col] == player) {
						if (col == getGameSettings().nrCols/2){
							bonus = bonus + 10;
						}
						count = count + 1;
					}if (board[row][col] == board[row][col + col_plus] && board[row][col] != player && board[row][col] != 0){
						if(col == getGameSettings().nrCols/2){
							bonus_opp = bonus_opp +10;
						}
						count_opp = count_opp + 1;
					}if(board[row][col] != board[row][col + col_plus] && board[row][col] != 0 && board[row][col + col_plus] != 0){
						count =0;
						count_opp =0;
						break;
					}
				}

				if (count_opp ==  settings.minStreakLength - 1) {
					score = score - 4*2;
				}if(count == getGameSettings().minStreakLength) {
					score= score + 10000;
				}if (count == settings.minStreakLength - 1){
					score = score +5*2;
				}if (count == settings.minStreakLength - 2){
					score = score + 2*2;
				}if(count_opp == getGameSettings().minStreakLength){
					score = score -10000;
				}if(count_opp ==settings.minStreakLength - 2){
					score = score - 2*2;
				}
				score = score + bonus - bonus_opp;

			}
		}
		//score for up and down
		for (int row = 0; row < settings.nrRows - getGameSettings().minStreakLength + 1; row++) {
			for (int col = 0; col < settings.nrCols; col++) {
				count = 0;
				count_opp = 0;
				bonus_opp =0;
				bonus =0;
				for (int row_plus = 0; row_plus < getGameSettings().minStreakLength; row_plus++) {
					if (board[row][col] == board[row + row_plus][col] && board[row][col] ==player) {
						if(col == getGameSettings().nrCols/2){
							bonus = bonus +10;
						}
						count = count + 1;
					}
					if(board[row][col] == board[row + row_plus][col] && board[row][col] != player && board[row][col] !=0 ){
						if(col == getGameSettings().nrCols/2){
							bonus_opp = bonus_opp +10;
						}
						count_opp = count_opp + 1;
					}
					if (board[row][col] != board[row + row_plus][col] && board[row][col] != 0 && board[row + row_plus][col] != 0) {
						count =0;
						count_opp =0;
						break;
					}
				}

				if (count_opp ==  settings.minStreakLength - 1) {
					score = score - 5;
				}if(count == settings.minStreakLength ) {
					score= score + 10000;
				}if (count == settings.minStreakLength - 1){
					score = score +5;
				}if (count == settings.minStreakLength - 2){
					score = score +2;
				}if(count_opp == settings.minStreakLength ){
					score = score -10000;
				}if(count_opp ==settings.minStreakLength - 2){
					score = score - 2;
				}
				score = score + bonus - bonus_opp;
			}
		}

			//score for Right Diagonal
			for (int row = 0; row < settings.nrRows - getGameSettings().minStreakLength + 1; row++) {
				for (int col = getGameSettings().minStreakLength - 1; col < settings.nrCols; col++) {
					count = 0;
					count_opp = 0;
					bonus_opp =0;
					bonus =0;
					for (int plus = 0; plus < getGameSettings().minStreakLength; plus++) {
						if (board[row][col] == board[row + plus][col - plus] &&  board[row][col] ==player) {
							if(col == getGameSettings().nrCols/2){
								bonus = bonus +10;
							}
							count = count + 1;
						}
						if(board[row][col] == board[row + plus][col - plus] && board[row][col] !=player&& board[row][col] !=0){
							if(col == getGameSettings().nrCols/2){
								bonus_opp = bonus_opp +10;
							}
							count_opp = count_opp + 1;
						}
						if (board[row][col] != board[row + plus][col - plus] && board[row][col] != 0 && board[row + plus][col - plus] != 0) {
							count =0;
							count_opp =0;
							break;
						}
					}

					if (count_opp ==  settings.minStreakLength - 1) {
						score = score - 5*2;
					}if(count == settings.minStreakLength ) {
						score= score + 10000;
					}if (count == settings.minStreakLength - 1){
						score = score +5*2;
					}if (count == settings.minStreakLength - 2){
						score = score +2*2;
					}if(count_opp == settings.minStreakLength ){
						score = score -10000;
					}if(count_opp ==settings.minStreakLength - 2){
						score = score - 2*2;
					}
					score = score + bonus -bonus_opp;

				}
			}

			// score for Left Diagonal
			for (int row = 0; row < settings.nrRows - getGameSettings().minStreakLength + 1; row++) {
				for (int col = 0; col < settings.nrCols - getGameSettings().minStreakLength + 1; col++) {
					count = 0;
					count_opp = 0;
					bonus_opp =0;
					bonus =0;
					for (int plus = 0; plus < getGameSettings().minStreakLength; plus++) {
						if (board[row][col] == board[row + plus][col + plus] &&  board[row][col] ==player) {
							if(col == getGameSettings().nrCols/2){
								bonus = bonus +10;
							}
							count = count + 1;
						}
						if(board[row][col] == board[row + plus][col + plus] && board[row][col] !=player&& board[row][col] !=0){
							if(col == getGameSettings().nrCols/2){
								bonus_opp = bonus_opp +10;
							}
							count_opp = count_opp + 1;
						}
						if (board[row][col] != board[row + plus][col + plus] && board[row][col] != 0 && board[row + plus][col + plus] != 0) {
							count =0;
							count_opp =0;
							break;
						}
					}
					if (count_opp ==  settings.minStreakLength - 1 ) {
						score = score - 5*2;
					}if(count == settings.minStreakLength) {
						score= score + 10000;
					}if (count == settings.minStreakLength - 1){
						score = score +5*2;
					}if (count == settings.minStreakLength - 2){
						score = score +2*2;
					}if(count_opp == settings.minStreakLength ){
						score = score -10000;
					}if(count_opp ==settings.minStreakLength - 2){
						score = score - 2*2;
					}
					score = score + bonus -bonus_opp;
				}
			}
			return score;
		}

}
