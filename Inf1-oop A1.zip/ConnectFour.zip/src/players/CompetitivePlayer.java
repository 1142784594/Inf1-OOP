package players;

import game.Model;
import interfaces.IModel;
import interfaces.IPlayer;

/**
 * Implementing this player is an advanced task.
 * See assignment instructions for what to do.
 * If not attempting it, just upload the file as it is.
 *
 * @author <YOUR UUN>
 */
public class CompetitivePlayer implements IPlayer
{
	// A reference to the model, which you can use to get information about
	// the state of the game. Do not use this model to make any moves!
	private IModel model;
	
	// The constructor is called when the player is selected from the game menu.
	public CompetitivePlayer()
	{
		// You may (or may not) need to perform some initialisation here.
	}
	int all =0;
	int turn_AI;

	// This method is called when a new game is started or loaded.
	// You can use it to perform any setup that may be required before
	// the player is asked to make a move. The second argument tells
	// you if you are playing as player 1 or player 2.
	public void prepareForGameStart(IModel model, byte playerId)
	{
		this.model = model;
	}
	
	// This method is called to ask the player to take their turn.
	// The move they choose should be returned from this method.


	public int[] minimax(IModel model, int depth,int alpha,int beta, boolean player,int myPlayer){
		int[] result = new int[2];
		int a = 100;
		int value;
		int new_score;
		int column = 100;
		Model model_copy = new Model(model) ;
		if (model_copy.getGameStatus() == myPlayer ){
			result[0] = a;
			result[1] =10000000;
			return result;
		}if(model_copy.getGameStatus() != 0 && model_copy.getGameStatus() != 3 && model_copy.getGameStatus() != myPlayer){
			result[0] =a;
			result[1]=-10000000;
			return result;
		}if(model_copy.getGameStatus() == 3){
			result[0] = a;
			result[1] = 0;
			return result;
		}if (depth == 0){
			result[0] = a;
			result[1] =	model_copy.score_count(myPlayer);
			return result;
		}if (player){
			value = -1000000000;
			for(int i = 0; i < model.getGameSettings().nrCols; i++){
				if(model_copy.isMoveValid(i)){
					Model model1 = new Model(model);
					//model1.changeSum(myPlayer+1);
					model1.makeMove(i);
					new_score = minimax(model1, depth-1, alpha, beta,false, myPlayer)[1];
					if (new_score > value){
						value = new_score;
						column = i;
					}
					if (value>=beta){
						break;
					}
					alpha = Math.max(alpha,value);
				}
			}
		}else{
			value = 1000000000;
			for(int i = 0; i< model.getGameSettings().nrCols;i++){
				if(model_copy.isMoveValid(i)){
					Model model1 = new Model(model);
					//model1.changeSum(myPlayer);
					model1.makeMove(i);
					new_score = minimax(model1, depth-1, alpha, beta,true, myPlayer)[1];
					if (new_score < value){
						value = new_score;
						column = i;
					}
					if (value <= alpha){
						break;
					}
					beta = Math.min(beta,value);
				}
			}
		}
		result[0] = column;
		result[1]= value;
		return result;
	}


	public int chooseMove()
	{
		// Until you have implemented this player, it will always concede.
		//System.out.print(minimax(model, 8,-1000000000,1000000000,true, model.getActivePlayer())[1]);
		return minimax(model, 8,-1000000000,1000000000,true, model.getActivePlayer())[0];
	}
}
