package players;

import game.Model;
import interfaces.IModel;
import interfaces.IPlayer;

/**
 * Implementing this player is an advanced task.
 * See assignment instructions for what to do.
 * If not attempting it, just upload the file as it is.
 *
 * @author <YOUR UUN>
 */
public class WinDetectingPlayer implements IPlayer
{
	// A reference to the model, which you can use to get information about
	// the state of the game. Do not use this model to make any moves!
	private IModel model;
	private int c = 0;
	private int count = 0;
	int now;
	int step = 11;
	
	// The constructor is called when the player is selected from the game menu.
	public WinDetectingPlayer()
	{
		// You may (or may not) need to perform some initialisation here.
	}
	
	// This method is called when a new game is started or loaded.
	// You can use it to perform any setup that may be required before
	// the player is asked to make a move. The second argument tells
	// you if you are playing as player 1 or player 2.
	public void prepareForGameStart(IModel model, byte playerId)
	{
		this.model = model;
		now = 0;
		count =0;
		c =0;

	}
	
	// This method is called to ask the player to take their turn.
	// The move they choose should be returned from this method.
	public int chooseMove() {
		step = 11;
		for (int i = 0; i < model.getGameSettings().nrCols; i++) {
			Model model1 = new Model(model);
			//System.out.print(model.getActivePlayer());
			//model1.setSum(1);
			if (model1.getPieceIn(0, i) == 0) {
				model1.makeMove(i);
				//System.out.print(model1.getActivePlayer());
			}
			if (model1.getGameStatus() == model.getActivePlayer()) {
				return i;
			}
			//System.out.print(model1.getActivePlayer());
			//System.out.print("\n");
		}

		for (int i = 0; i < model.getGameSettings().nrCols; i++) {
			Model model2 = new Model(model);
			if(model2.isMoveValid(i)){
				model2.makeMove(i);
				boolean a = true;
				for(int j = 0; j < model.getGameSettings().nrCols; j++ ){
					c = model2.getActivePlayer();
					if(model2.isMoveValid(j)){
						model2.makeMove(j);
						if (model2.getGameStatus() == c && c != 0){
							a = false;
							break;
						}
						model2 = new Model(model);
						model2.makeMove(i);
					}
				}
				if(a){
					return i;
				}
			}
		}
		return -1;
	}
}
